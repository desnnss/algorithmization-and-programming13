import java.util.Scanner;

public class ex_1 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String text = in.nextLine();

        String prepared = text.toLowerCase().replace(" ", "");
        String result = "";

        for (int j = prepared.length() - 1; j >= 0; j--) {
            result += prepared.charAt(j);
        }

        if (prepared.equals(result)) {
            System.out.println("Це паліндром.");
        } else {
            System.out.println("Це не паліндром.");
        }
    }
}
