import java.util.Scanner;

public class ex_2 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String line = in.nextLine();

        String output = "";

        for (int k = line.length() - 1; k >= 0; k--) {
            output += line.charAt(k);
        }

        System.out.println("Інвертований рядок: " + output);
    }
}
