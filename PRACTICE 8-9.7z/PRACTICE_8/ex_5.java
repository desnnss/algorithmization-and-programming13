import java.util.Scanner;

public class ex_5 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("Введіть рядок: ");
        String text = in.nextLine();

        String wordA = "погане";
        String wordB = "слово";

        String replA = "***";
        String replB = "[цензура]";

        String output = text;

        output = output.replace(wordA, replA);
        output = output.replace(wordB, replB);

        System.out.println("Результат: " + output);
    }
}
