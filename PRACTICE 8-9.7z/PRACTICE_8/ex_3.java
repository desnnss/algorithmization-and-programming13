import java.util.Scanner;

public class ex_3 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String text = in.nextLine().trim() + " ";

        String word = "";
        String minWord = "";
        String maxWord = "";

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c != ' ') {
                word += c;
            } else {
                if (!word.equals("")) {

                    if (minWord.equals("") || word.length() < minWord.length()) {
                        minWord = word;
                    }

                    if (word.length() > maxWord.length()) {
                        maxWord = word;
                    }

                    word = "";
                }
            }
        }

        System.out.println("Найменше слово: " + minWord + " (" + minWord.length() + " символи)");
        System.out.println("Найдовше слово: " + maxWord + " (" + maxWord.length() + " символи)");
    }
}
