import java.util.Scanner;

public class ex_4 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("Введіть рядок: ");
        String text = in.nextLine();

        String output = "";
        boolean nextUpper = false;

        for (int i = 0; i < text.length(); i++) {
            char symbol = text.charAt(i);

            if (symbol == '-' || symbol == '_') {
                nextUpper = true;
            } else {
                if (nextUpper) {
                    output += Character.toUpperCase(symbol);
                    nextUpper = false;
                } else {
                    output += Character.toLowerCase(symbol);
                }
            }
        }

        System.out.println("CamelCase: " + output);
    }
}
