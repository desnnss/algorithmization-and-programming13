import java.util.Scanner;

public class practice_9 {

    public static String readCorrectLine() {
        Scanner in = new Scanner(System.in);
        String line;

        while (true) {
            System.out.println("Введіть строку (мінімум 2 слова, кожне не менше 3 символів):");
            line = in.nextLine().trim();

            String[] parts = line.split("\\s+");

            if (parts.length < 2) {
                System.out.println("Помилка: потрібно мінімум 2 слова.");
                continue;
            }

            boolean ok = true;
            for (String p : parts) {
                if (p.length() < 3) {
                    ok = false;
                    break;
                }
            }

            if (ok) {
                return line;
            } else {
                System.out.println("Помилка: кожне слово має містити мінімум 3 символи.");
            }
        }
    }

    public static String flipAll(String text) {
        StringBuilder buf = new StringBuilder(text);
        return buf.reverse().toString();
    }

    public static String flipWords(String text) {
        String[] arr = text.split("\\s+");
        StringBuilder res = new StringBuilder();

        for (String s : arr) {
            res.append(new StringBuilder(s).reverse()).append(" ");
        }

        return res.toString().trim();
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        String value = readCorrectLine();

        System.out.println("Оберіть дію:");
        System.out.println("1 - Перевернути всю строку");
        System.out.println("2 - Перевернути кожне слово окремо");

        int option = in.nextInt();

        if (option == 1) {
            System.out.println("Результат:");
            System.out.println(flipAll(value));
        } else if (option == 2) {
            System.out.println("Результат:");
            System.out.println(flipWords(value));
        } else {
            System.out.println("Невірний вибір.");
        }
    }
}
